package dev.tracking.lossandbenefit.service;

import dev.tracking.lossandbenefit.dto.UserDto;
import dev.tracking.lossandbenefit.entity.UserEntity;
import dev.tracking.lossandbenefit.exception.UserNotFoundException;
import dev.tracking.lossandbenefit.repository.UserSessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class UserService {
@Autowired
private UserSessionRepository userSessionRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserDto toDto(UserEntity userEntity) {
        return new UserDto(userEntity.getId(), userEntity.getUsername(), userEntity.getEmail(), userEntity.getLoginTime());
    }
    public UserEntity toEntity(UserDto userDto) {
        UserEntity userEntity = new UserEntity();
        userEntity.setId(userDto.getId());
        userEntity.setUsername(userDto.getUsername());
        userEntity.setEmail(userDto.getEmail());
        userEntity.setLoginTime(userDto.getLoginTime());
        return userEntity;
    }
    public List<UserDto> getAllUsers() {
        return userSessionRepository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }
    public Optional<UserDto> getUserById(Long id) {
        Optional<UserEntity> userEntity = userSessionRepository.findById(id);
        return userEntity.map(this::toDto);
    }

    public UserDto addUser(UserDto userDto, String password) {
        UserEntity userEntity = toEntity(userDto);
        userEntity.setPassword(passwordEncoder.encode(password));
        userEntity = userSessionRepository.save(userEntity);
        return toDto(userEntity);
    }

    public UserDto updateUser(Long id, UserDto userDto) {
        return userSessionRepository.findById(id).map(existuserEntity -> {
            existuserEntity.setUsername(userDto.getUsername());
            existuserEntity.setEmail(userDto.getEmail());
            existuserEntity.setLoginTime(LocalDateTime.now());
            existuserEntity = userSessionRepository.save(existuserEntity);
            return toDto(userSessionRepository.save(existuserEntity));

        })
                .orElseThrow(() -> new UserNotFoundException("User with id " + id + " not found"));
    }


}
