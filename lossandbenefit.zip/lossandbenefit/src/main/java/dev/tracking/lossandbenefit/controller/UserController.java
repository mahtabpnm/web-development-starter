package dev.tracking.lossandbenefit.controller;

import ch.qos.logback.core.model.Model;
import dev.tracking.lossandbenefit.dto.UserDto;
import dev.tracking.lossandbenefit.entity.UserEntity;
import dev.tracking.lossandbenefit.repository.UserSessionRepository;
import dev.tracking.lossandbenefit.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * @return users
     */
    @GetMapping("/users")
    public List<UserDto> getUsers(){
        return userService.getAllUsers();
    }

    /**
     * @param id user id
     * @return user
     */
    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUserById(@PathVariable Long id){
        Optional<UserDto> user = userService.getUserById(id);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * @param userDto user
     * @return user
     */
    @PostMapping
    public ResponseEntity<UserDto> addUser(@RequestBody UserDto userDto, @RequestParam String password){
        UserDto user = userService.addUser(userDto, password);
        return ResponseEntity.ok(user);
    }

    /**
     * @param userDto user
     * @return  user
     */
    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable Long id, @RequestBody UserDto userDto){
        UserDto updatedUser = userService.updateUser(id, userDto);
        return ResponseEntity.ok(updatedUser);

    }
}
