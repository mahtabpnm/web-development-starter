-- Create the users table
-- The password is hashed using BCrypt with a strength of 10
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    login_time TIMESTAMP NOT NULL
);

-- Insert sample data into the users table
INSERT INTO users (name, email, password, login_time) VALUES ('John Doe', 'john.doe@example.com', '$2a$10$DowJ4v1U/1nwo.WcZFFLyeT4eU4s1.JMd9uPqM/gP5o.YzTzq2Taa', '2023-01-01 00:00:00');
INSERT INTO users (name, email, password, login_time) VALUES ('Jane Smith', 'jane.smith@example.com', '$2a$10$DowJ4v1U/1nwo.WcZFFLyeT4eU4s1.JMd9uPqM/gP5o.YzTzq2Taa', '2023-01-02 00:00:00');